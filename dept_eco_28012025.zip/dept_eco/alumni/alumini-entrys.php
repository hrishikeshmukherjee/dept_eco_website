<?php
include '../controller.php';

$name=$_POST['name'];
$academics=$_POST['academics'];
$profession=$_POST['profession'];
$current_add=$_POST['current_add'];
$permament_add=$_POST['permament_add'];
$email=$_POST['email'];
$phone_number=$_POST['phone_number'];

if($name==""){
  ?>
  <script type="text/javascript">
  alert("Please enter Name");
  window.history.go(-1);
  </script>
  <?php

}
else{


  $currentDate=date('Y-m-d');
  $currentTime=date('H:i:s');
  mysqli_query($conn,"INSERT INTO `alumni` (`name`, `academics`, `profession`,`current_add`, `permament_add`, `email`,`phone_number`,`stat`) VALUES ('$name','$academics','$profession','$current_add','$permament_add','$email','$phone_number','1');");
  ?>
  <script type="text/javascript">
  alert("Done");
  document.location="alumni-entry.php";
  </script>
  <?php
}

 ?>
