<?php
include "../controller.php";
$srcvalue=$_REQUEST['srcvalue'];
if($srcvalue!=""){
    $srcvalue1="%".$srcvalue."%";
    $srcvalue12 = "AND (`name` LIKE '$srcvalue1' OR `academics` LIKE '$srcvalue1')";
}
else{
    $srcvalue12="";
}
?>
<div class="row">
                <?php

    
      $getImg = mysqli_query($conn,"SELECT * FROM `alumni` WHERE `stat`='1' $srcvalue12");
      while ($rowImg = mysqli_fetch_array($getImg)) {
          $sl = $rowImg['sl'];
          $name = $rowImg['name'];
          $academics = $rowImg['academics'];
          $profession = $rowImg['profession'];
          $current_add = $rowImg['current_add'];
          $permament_add = $rowImg['permament_add'];
          $email = $rowImg['email'];
          $phone_number = $rowImg['phone_number'];
      
      ?>
                      <div class="col-md-4">
                    <div class="card">
                        <div class="card-header d-flex align-items-center">
                            <img src="img/img.jpg" class="rounded-circle me-3" width="100px" height="100px" alt="Profile Picture">
                            <div>
                                <h4 class="mb-0"><?php echo "$name";?></h4>
                                <small>(<?php echo "$academics";?>, <?php echo "$profession";?>)</small>
                            </div>
                        </div>
                        <div class="card-body">
                            <p>
                                Current address: <?php echo "$current_add";?> <br>
                                Permanent address: <?php echo "$permament_add";?> <br>
                                Email: <?php echo "$email";?> <br>
                                Phone number: <?php echo "$phone_number";?><br>
                            </p>
                        </div>
                    </div>
                </div>
        <?php }?>
                </div>

                <!-- Repeat for additional cards -->
</div>