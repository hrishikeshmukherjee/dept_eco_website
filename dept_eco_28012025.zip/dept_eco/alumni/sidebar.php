<div class="sidebar">
        <h2 class="text-center py-3">Alumni</h2>
        <ul class="list-group list-group-flush">
            <li class="list-group-item bg-dark text-white">
                <a href="../index.php" class="text-white">Home</a>
            </li>
            <!--<li class="list-group-item bg-dark text-white">
                <a href="collaboration.php" class="text-white">Collaboration</a>
            </li>-->
            <li class="list-group-item bg-dark text-white">
                <a href="index.php" class="text-white">Directory</a>
            </li>
            <li class="list-group-item bg-dark text-white">
                <a href="connection-alumini.php" class="text-white">Connecting with Alumni</a>
            </li>
        </ul>
    </div>