-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 07, 2024 at 02:29 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `depteco`
--

-- --------------------------------------------------------

--
-- Table structure for table `addmission_link`
--

CREATE TABLE `addmission_link` (
  `sl` int(11) NOT NULL,
  `link` varchar(10000) NOT NULL,
  `stat` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `addmission_link`
--

INSERT INTO `addmission_link` (`sl`, `link`, `stat`) VALUES
(1, 'https://www.turboimagehost.com/p/97556421/Kdcaf17be73q.jpg.html', 1),
(2, 'https://www.turboimagehost.com/p/97556421/Kdcaf17be73q.jpg.html', 1);

-- --------------------------------------------------------

--
-- Table structure for table `dept_gallery`
--

CREATE TABLE `dept_gallery` (
  `sl` int(11) NOT NULL,
  `img_path` varchar(2000) NOT NULL,
  `name` varchar(1000) NOT NULL,
  `year` varchar(100) NOT NULL,
  `fav` varchar(200) NOT NULL,
  `words` varchar(1100) NOT NULL,
  `stat` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `dept_magazine`
--

CREATE TABLE `dept_magazine` (
  `sl` int(11) NOT NULL,
  `img_path` varchar(200) NOT NULL,
  `headline` varchar(2000) NOT NULL,
  `article` longtext NOT NULL,
  `userid` varchar(1100) NOT NULL,
  `roll` varchar(2000) NOT NULL,
  `date` varchar(200) NOT NULL,
  `stat` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dept_magazine`
--

INSERT INTO `dept_magazine` (`sl`, `img_path`, `headline`, `article`, `userid`, `roll`, `date`, `stat`) VALUES
(1, 'assets/img/gallery/AVirup work (2).png', 'Biswajit &sourish', ';gfhjhgfghjkolkjhgfghjklkjhgfghjklkjhgfghjkjhgfghjklkjhgfghjk,mnbvbnm,mnbvcvbnm,mnbv', 'atunukumar das', '205', '2024-06-06', 0);

-- --------------------------------------------------------

--
-- Table structure for table `dept_notice`
--

CREATE TABLE `dept_notice` (
  `sl` int(11) NOT NULL,
  `img_path` varchar(6000) NOT NULL,
  `instructions` varchar(1000) NOT NULL,
  `stat` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `edu_login`
--

CREATE TABLE `edu_login` (
  `sl` int(11) NOT NULL,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `fullname` varchar(30) DEFAULT NULL,
  `mobile` varchar(15) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `logintime` varchar(20) DEFAULT NULL,
  `loginfail` varchar(20) DEFAULT NULL,
  `userlevel` int(11) NOT NULL,
  `edt` varchar(20) DEFAULT NULL,
  `edtm` varchar(20) DEFAULT NULL,
  `eby` varchar(20) DEFAULT NULL,
  `stat` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `edu_login`
--

INSERT INTO `edu_login` (`sl`, `username`, `password`, `fullname`, `mobile`, `email`, `logintime`, `loginfail`, `userlevel`, `edt`, `edtm`, `eby`, `stat`) VALUES
(1, 'developer', '$2y$10$VZL2MY6thEjtGLiFoWI.1OK/fdl4X/94Sx/ShAYHiOWxk.ZJtCida', 'Biswajit Mukherjee', '6295317859', 'biswajitkpa6@gmail.c0m', '2024-06-07 08:03:44', NULL, 0, NULL, NULL, NULL, 1),
(2, 'dkc', '$2y$10$t1P/MvhJYc75FeXMYYj1.e/Vp.x3y/7/Q838PH50ED1xVhJXd0URq', 'Dev Kumar Chokarvarty', '8017375470', 'test@gmail.com', '2024-02-25 18:46:36', NULL, 5, NULL, NULL, NULL, 1),
(3, 'atana', '$2y$10$Ik6.Wl0S7UNHoq8CBxREieHW5/mP.f1vO2O2Jrf2a/H4/CUWvXnDe', 'atunukumar das', '12345678987654', 'biswajitkpa6@gmail.c', '2024-04-07 01:42:53', NULL, 10, NULL, NULL, NULL, 1),
(5, 'Megha', '$2y$10$Ik6.Wl0S7UNHoq8CBxREieHW5/mP.f1vO2O2Jrf2a/H4/CUWvXnDe', 'Megha Bangari', '654754756', 'meghabangari7009@gma', '2024-06-01 01:44:53', NULL, 10, NULL, NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `login_key`
--

CREATE TABLE `login_key` (
  `sl` int(11) NOT NULL,
  `username` varchar(30) DEFAULT NULL,
  `loginKey` varchar(500) DEFAULT NULL,
  `edt` varchar(30) DEFAULT NULL,
  `stat` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login_key`
--

INSERT INTO `login_key` (`sl`, `username`, `loginKey`, `edt`, `stat`) VALUES
(1, 'teacher', 'd165ef368af8725549bfd561209ed7a2d107113c5451ea7d0445d050110212c5f1ffef4f0ebfd1da48b82a6fa7d87c72b5385c1bb47d14f8ef2ce8ba1c564d5994e03788621f226c4c77cc74da075efa2ebdd3d9f302728bfc6ce76710d14d6e379403745fea5a85a2a63dd9ff8327865fbb6fefeb1e02d7145011a563a4f5d5', '2024-02-18 15:49:47', 0),
(2, 'developer', '1596beb43792aeeee225673a23e40c08a5b9df645aeb72df9d60dd9885f6cdf456dfc883e15ba00e790181cbaec8908d58c8effaa94cf2f695d50747e3f46591bbd775f67629c3297d29f785ae70a9191febe742499671f25114b19a54f4f4737dec6bfb4edafc3fc48e39608383b13ac478494e3b051f7ad26500bf2af9d1c1', '2024-02-25 16:44:40', 0),
(3, 'developer', '47cd95609183591622f11e05eab118913e89ee4731816466a78440dd635329e77a73cd88b476f03fc7919cb6c616c2278be76fd6ab22fe1159a80e7e030f26570f936440dd8e5014175c3248d6ef6f19c1df69a68ed4d397ab691e1434652a2aa236978177cd74775e53d9911098ce00defcc4afee22c50113158dd74ee9fa22', '2024-02-25 16:58:32', 0),
(4, 'developer', 'de7476bf2f1db362e63fe36ad238ab564a8c00f4ab7e4ef6957d15fe10e42c5fa6f3ab6f8a2a13c3a182cd307c66eb235b2cc4a3263746bc10c76423bcadefe91d950ab38b62190e5a763a618d941e8c491ff1a15559776c40ddc81d0d43908cf4bb6ae30bdcf27621d5e06363dce8f9511a8c4c7c29376f6a4bac645ad85591', '2024-02-25 17:10:40', 0),
(5, 'developer', 'bd4f379762f73726f66ddc7a1cce1f236a8d9026415b9a31b4f92f94950b7dbc114af43cf34042f0a1095cece566ecee029f927e65faae54a08f31f8665f3510ab6d11d03be005a2d99becc9f9d8e6298570024d62e93a565793ec1e3e2af7f38caf45b73f8e4a6a0f449ee3bcbc68230cdbf1c5aecf390296e284e0074b0b6c', '2024-02-25 17:21:46', 0),
(6, 'developer', 'a93367d4f63640a7eec6893e483ddcec05cc82708f0cf7dbbf21a3375cb1534a1372a3d604dd1a1a4c315aec356dff27477c57eb993ecc9d25a89ba9365b9669c3f0894bbd0e0713f9812e2802ec44f347419d0c7b588264b0d7e92e615f3fac51bc63a38654684cd9126fbb1a3cc9960b199d73da1059ec5199eaf2cdbe9590', '2024-02-25 17:35:46', 0),
(7, 'developer', 'd32b47dca10660e6fbc28b5c8797cf2e7d935b817ce724e5c00aa288c8f0fefd9d603acfa7cbf8c45c09f2674cc7e2aad14f9f3fed0cb8d462b295b79b7c8b5c7bfacbbcd77240dda37f562d30a371843a629b0dced0535281cf3484e1a19fa21a9ca86a8b3d446de8e0727080facf73fd79bcaec4ec51319626af9aa37bc0d0', '2024-02-25 18:29:39', 0),
(8, 'developer', 'cc06a55bb7403b2436dd3b3ab574168c1c2753122af5d94affcb42fca87b3083f3f745185ae626b6e7c2221ed7b538beac71d978fbe275b2b8866d9dafd2d7c49a9d6aa95e33cf09c10b0d3a9d4490d877572e2742d0538d1737ef1c931c94eb4fdddf5029fdfbf0196007c3ac031c967e1d602ee3be37580f08c145ff3d607b', '2024-02-25 18:40:10', 0),
(9, 'teacher', '416919c8c3876b0854942d5e9848e371035c34c37f2e13b56128dd5e55de611d7af07689a92bf3eb08994b3dda7b29eaf63f533ebb6b1816fb5d782d66bf0d318cf796bbc1f9f615df44e40c332cbc717457b520fbf9ec44061d4839aff9483cfb4669c901d8f83ef87ebd626f8b65f12acb8dbd77676c773a27451de491e716', '2024-02-25 18:46:36', 1),
(10, 'developer', '4527491835be2d29c62c1ee9bf0da04e7e9b560f5b54bcc590b0e0b1b6ef54758245a8adfe4c5c98ea032309a0734c41ad19e826a72f89e02f0f29c0c334a60ffa472f28b4f9836c0020855d1d5d8f0518e1febb752bcf475c34a9b3b1f87f5ba9f5fed0b5897dc34056a04c54cea59a4b4f426344ac5f7fd17633be870a92b8', '2024-03-22 15:12:42', 0),
(11, 'developer', 'e1dd0d42da7de97593e872ea4de53bb7902fea58316c0025aac4d235f424c477fa9ad7104f61bee4d9e63a45761e11d10b666993beca547cda15320170c92163d40346c62ccc736e6b1c5b499281c1e4c600ed9ffa93397015884f18445597b5d3fcab832f7c96b32ea7c0a4e2887ac8a9a6210163b509cb2b5bf16bc622d983', '2024-04-04 16:26:28', 0),
(12, 'developer', '0b8fd296c27208ac48d60ef593e79de3037368cc08c1ec03417c0ff05eaccf7b6b15650c3b3408a9f15de4664e9a738089b1b9593cfaf96410eb99e1b3e7199b826cadabfb52cf6a641a2f534d6f5fed87bc2d71e1d6871da3f99977c21e7d350da054067ad34528ffc609bbf5f21ee5d204b565d45b4954c68c6ca6331f0be7', '2024-04-04 16:36:36', 0),
(13, 'atana', '4f453adaadb710229d80e1f0dead88671e0bffe8afda3b0c82b08f1042c79ef5e621a19c0706878ffa3f34b69365dd99173bb324fddb722739ec6a0862a605c89116dfdf956ec05831f4ae0b4d2378d713a8207730284a1ccb05df4bb274f67d3798ca73f5616dfea09ae6053212c227ff02bea0172c62a300fa10366f7f0c22', '2024-04-07 01:42:53', 0),
(14, 'developer', 'e6e79b730beabf2cf195f96edce8263d1e43a384653b356ae3037d2eed58e0bba93dfe37b6eb2b99cb2c201a50e82ca8030bf9ea77d0698dd333aac61cc05e68d21a212176913104a6d8dcef2adf76116db1eb8b589c6008095707e5f8d07ca63ab4d5dabb27207fec793f90b369cd28f54c6979cb10f2b0ce726f783f013f93', '2024-04-07 21:25:35', 0),
(15, 'developer', '570e96f754582df405c99a80527cc24e4f1256a6fd40a40ce60751b24cb208b038ab354e300a32e4f312f5b264dde41f6c010acefc25b2b5fe1e4fcb89d4b9ce5c8421e030d36cf1699242d775441a9cd4efec4e5811ba2602951cb21c667cc5319261204e6de2a630f89274ba853cb474b5abcd86958ab93e530adf92aeb594', '2024-04-20 03:38:34', 0),
(16, 'developer', 'e610ca655badcf6888167167587f5f1d2c62d3366cab4d9eefbbf7431633df5292735dc3d8ba209aeeb7d5ac8fdfffc7684f7e9d6bba8e3dd09b638ba2185f257e6edc68d73de80937ad74382d16ce657f063afe92b36b1fea6a92079a5203475f718f0076f2e41306afb3d7596d55df37a43b04d55c5aa3e7c9f2e5f8e8c84b', '2024-04-20 03:59:41', 0),
(17, 'developer', 'f5acdca66d4e6ce5223b1be56ec8a301b0dd7ba06c91054c593f4c048bcc77d5ac398a5c31a6798b6277f1ff8ec2481d87e04161c18a485f98fdf594fc0e0d844749766a8bc46d9e4654de1dead280aa084f7393ab676f535c1c5191040abb13946489bc4bee1a2eaac1112507f46a31d0ee4fbe979a8993f087c00f1267c4d5', '2024-04-20 04:19:28', 0),
(18, 'developer', 'df1c6a93b5d44f4d3799226d2d7d1aa009e876c4faeebf119120c5c5f354e0aae1109b6f470f2d196805100d43f88c507b681ea556baffb9ab32f6de889d85386a9ffaf5b1fbd3e4fbb2c0d3e7cb420e58cc9bf6218a252f765cc67b741ec4ee8014665e664c677d1f67a243b48dc36983d2b37abf1ec9be31d3baea214746d5', '2024-04-20 10:57:41', 0),
(19, 'developer', '165aded2ef8b673c1d9a9cd2ceb0d1590d564e471e87e086fc169bb5e56052ccf876e7a47d51448c80208a8064ff26f1ec62e456db635043afafac4df0c8726ddaee2cb1ff6510c11d46636b6dbd51a8ca53fc2e1b880144ba96fc3ecedf638b6176b654e6bcd19d413d87b4268427b85452684165d354f63353141ea845cec7', '2024-04-20 11:07:26', 0),
(20, 'developer', '559e5d398606d4af3976138a450194da5cae96bc64c9e398e7cddb199e0497e8635fbc31a040e5dc33d399825381d7e40d9489dae3c1887b470361f3af338a86136c6371cbd8dabac48cee899009e7a13df083cfb62e5debd95a47cd93847771fdceb10bc43a9987b788e8bb3b74c840c902fba534daeb5e7381fd171a38bccc', '2024-04-20 12:22:01', 0),
(21, 'developer', 'b5d7985bb283d3b3daa488151fd7f00be2f97b103c6336373ec71c6ad0673241ec5bf9c1a8edca7d28b7717c5c1f8e437fe735a6fe933b7e6227eaa12d33a4db457e63c662e982573fceebe1a7e2633c2ae1db31d9dd485c00d29c7e5ac0de6b83bb8000692928afb48be463692fd70008cd75f806424eea4401433b6c419beb', '2024-04-21 00:18:18', 0),
(22, 'developer', '97bc07a69590a160e41fc42d13602fcddf0e21283108fbf1a5b1979081fb7e445903f33245610ab66f4750cde108c80382d231eb6e4483fe4a7a12af92b01dfb8b9074ab37dc6e5412a4c84d4fdf20b50ff980ad95ae2ec9763b6e3ef290e926370d4f2a3d9a35007c3549edeb5307f3ee25369cc8bef3b444399000aa66f642', '2024-04-21 00:25:21', 0),
(23, 'developer', '1f6985eeb7563b89216b5f8f8ba2d96d06f464167f0e642e679490bf1b366a7aac55ba57bd49db501b70b51e5ca83fecabbd38cafa7adaa56396723510d0acded3371905b37708f8696a746308f22ae96d402bb3ed1dc4bc2a5e70db09e4b63f129e03f1dc03e538b237058d04f5a4eecc422505837808a018939cbd380d0816', '2024-04-21 00:50:08', 0),
(24, 'developer', 'e121ba7ed80765cc59bf36a4f512c2bcaf67009ca51ca3885fdd46dfcf14744b250ce59c1f1e4173952d125c1c25a91e3bf8e2249bed597ed23f8033d471ab270f478d4a875a2c52221703f119f77709c4b89053bda767dcc9b4549b27ac3528c399a9baf805b07377ffb80b1ed2a67cdc4aa0bb50f6f2ee528f09a0386ffafc', '2024-04-21 00:51:32', 0),
(25, 'developer', '28cf0e138846753003a1fa6225f0935f0c8a64d8d65eab44709e62c5b37b9790616e4260a2d1732280f78bd82333df017623d94967ea880df120dfd64989f56c7e8f29273907a027337939f794af4764932ce954b34697c117d3930c5bb228eba260fe8f4eb6d2f305bddca6bed6b9dafd7e4da81a0c7b441a34aed59831fc19', '2024-04-21 01:02:20', 0),
(26, 'developer', 'a41ff9af4a2e5a41755f28301d099cb39fe3c60562429eaf2119ea8bb643bbe6379efb8f0d212e4d356e015a05da34433fe671d038ff3d8aa781ec82970eb376f606318b5e2648794f0f97368ecd0d608a982207788102dd74c79cc594ddc1dbe867fa24a50daf31de5a41c089f9387dcbe4a397e435ea2d830641477080dcb1', '2024-04-21 01:03:09', 0),
(27, 'developer', '9da8a5ab595ed1402a41bae77d107007dcbeb047012f25ff6e3cfa5d74f2a104fdee435d1e0cc11490bf5339bc94de16557d99585e73a514f3fe1e6031f7851619a52266fa68ee3f7e2bcd96f02de49c33cba5a27b249b3133da91020d0541475d1c76ac9d544e5f41ac42a8a9cb25f399d2deb2548ac483cee5c91bee3211ce', '2024-04-21 16:29:27', 0),
(28, 'developer', 'ada92ad74700b4541bff5f5b0d5ba0b2b8b86253457952de414f2db490c286e6cfbe8bd2959ac1d738a27cae0e9e5b43f2e17d90dab40b71a142dfc9711e5f1b9bc9c231d60e82f2cbc6e93dd4a5e7e8008335863da99d58f08fc5ac315ec7be299e727fd15bf792f4ace8a2214dfeaafe602641c951cc0714f6b614eec33ee9', '2024-04-21 16:38:59', 0),
(29, 'developer', '569a012e967eb2234560f78113db21770f71a85c9e720c6ed9df5b2013135ab539ab275ea1bc626e9a1b04c3e3b029b13986b292ecedea0e07dd7c2629d3da2b91afce2a54af2490aced66373294b2801fc6c6baa8870f888cc8562f9fc54e88e5bca5a65d777c9e8a996da1644ab11b32a308e3952e47b676a7f584f747b757', '2024-04-22 02:33:54', 0),
(30, 'developer', 'aff23e277a28f4ee13608c8adc397c3ba2099c2144a7a7946db3bb775885672f143c6e3cf7003cac981240ac1a5b50c7c6fd432e205b485a7e7778fbb856aa3c42667918c4795639865faf18bd117177f2bca911e3bb603214932cceb89aeac73c32b4f2eb55bf8be6b56a51c7236a1d002c611a7afb75fe3bb7c8ca61ce09d3', '2024-04-22 23:44:03', 0),
(31, 'developer', 'b949de63e6fc48a961481f9036951701b7facd957e6b5902a254bd3b99bd03d2613673d76b038ad856157b4e1cdbcf08700c367bb5b9f812f188a0633a80bc654095c7ad5d804c193ae3eb673ea829e17181e8be755593198d5e9707a84ed63dd98f5adc19b14ffcfb582f7c10d4b656e8397614eedf3dd425dbf14dd9d01f6e', '2024-04-22 23:47:35', 0),
(32, 'developer', 'b4b2aaf841db8fb35f69f787a313a3d9b0cc3775ab5fbddabd7cc64c963a5d509a06eb3d4af8d8116551a4b92368ebdca33a1bab4e8ee2301533316b0651765bad7b13d339bf45b9b327515e85cc4746ca833ceec359528b097faca30273bee2b44fd75ab4b3c7cb3dc0faf94018b5eeda9fef1bff0b86b80b37c6212eae2258', '2024-04-25 00:04:27', 0),
(33, 'developer', 'df8512db3ffe310cf90d888640eef910304355a0712dbad56e0444f129561a92c5b4de03f26f13e9a4cea6e9d0740b6de9b4953fe861a58f6b270a37c69a02a239d6d0c842fb62fba0b43869eb43394f289fc000ab3e1097d9262a219fc956e13f07bc60f865d80f19fceac06b8f5e578deac975a0f76115026d25a5eead0f36', '2024-04-25 00:19:39', 0),
(34, 'developer', '9098d4a711131277f9f511d7d26e0d534c5418b9280f729964e93c565d37470fa16f121e64cf53026ba075f6b04010bdd3a06a2f0c2b3db8e9b104cb4d0af06b608a41b46bbc88265b9752870a5a585407807088912874fdc6d6fd0c861878ba4d68c9daa2b78958c8b60e566785f58a5ff7818e6951ddf586abd180833a6cbd', '2024-04-25 00:22:08', 0),
(35, 'developer', '8b4f9951cc5726f99f345c76547d52614ac5c453ab19ca99c30962be37981276d9c529116e1e3f589e3ef09f2b72635388b61e15aba401c4648c59cb6f2001ec90d0e7c891981095d92c71e500475bdbd52b93424d7eac5b3211d5589847dfe46c2841665b5cfe53ea5432c888a3ac78121b9135ade9cb0ab5e97eb227a0aa35', '2024-04-25 00:28:04', 0),
(36, 'developer', '64c6f231c5c6610f007a997d8b76be0484dd48a806ce7ed71b4d5b1c9c63e87ca91544df2a8849859e204ba6eb1719e89e788bea39d5115605a1a74473b604e49b9c72a99b3281ce194aff0135f1f4534229186c7938d435a14721cbab4f192f8a9236351c14c8fe1d6509d92308381c2a9c9a7bb229327fe4e663c099c4abd8', '2024-04-27 20:16:20', 0),
(37, 'developer', '40e995adfd17c95ef36b225b13dc100eedee5d6d4f1a83fa2d508930a1045d04e4e1d23872c9d5cb874ce18a46b8b36bb00bd4e866903ad8480340ee0e49aedf239077c9b39205e969185c2dcf490d3c7eefc367fa4e4cc38c27c8f5e1684033ea54e9c4c5e933aa019ecb304757ad6b13ef96ea772b996f36ea935559b63495', '2024-05-02 14:42:28', 0),
(38, 'developer', '7a9a8da655f156f835a159ced4bcceb5ea9e6da51b818f15810bb4533fa36ce5e51647192ceae04aee4708c639bdb29387736a0037fc34354d7e8331e981709b8cc0e83454d0c5f97d783b2b7ebde7528bf782d9f0b76dfa497eff388e8439cf3102b1e76689def1e5472baf33665a76e38ec9e88eacef2de3b88c596153ef2b', '2024-05-05 18:16:54', 0),
(39, 'developer', '7d7ed601f970c7ad3dbfb2e7171a7266994b17516248917c4376b0b513f459321386e11056b3650480b386f7afe9885a5cb615d446f278097fd07bb8d5075f85f9ec281801f4a4315be4f5ae2bb47be2b639f63ea0a9bf947767c81fe6a5e97475ac988e3b2209aa5b5329d4299401ce9c2022c12e02fd5c34026250ca515af6', '2024-05-05 18:22:36', 0),
(40, 'atana', '5425e214fa073e5487bca0e008cd908138488acc684a3cf4354d9d3e4c1281c4d452a3d4e33dec401f2833941c4d4d16746dc46e79bd195d23a3898d7900605ba79058b7366bcb95bc75ab676ef1c5e49123c2348fa2ca5c20201292e77b5942e91d6b31a6da96a1eca67dd458a17e49e90fd31e1661194f21b5fe66df786a61', '2024-06-01 01:08:23', 0),
(41, 'developer', '99fbad6f252edddceb10c478bf4c9dbb907b673cb92ce0b06326e380e51efafb4d2ba75c100c2960629503de47c2c10cdc59570272d0dc01f69beab262c6cd2a8c42067c5750faa031de525e9e05f726bd75d48e6b822ae1c91076713f1465fab26b2d839ceafc1f95aa203840bc2db3867949800fb4d8e8a590321f6ffcdaeb', '2024-06-01 01:13:20', 0),
(42, 'developer', '5fbd3a4403cebf235060ffd37eb76124f7c9ccc702827185265289c80aeb79e19e421256449d163531563fcadd018dc14833fde1f394cf955c12f05817aa1003dbb211dcb792f8583f9aa58c40fd71f358864ab5c22470ea8698737431a8ea8dd7ce1417018a0b0b9c0fbb1f43aed4dd473e16ae830f2efb8ebc2d1e0e0ee37d', '2024-06-01 01:26:05', 0),
(43, 'developer', '68757fc542bc35c932257b8668e0094a24d9c541036bb4a3c3ba5899abd3d7de4ca55c07ec230d4b346ab97f0541c63271f49f91792ae645e32cca8794481e0fa47b79b9dc8bef4894f3efce7e8ded775334a21b254e1bc5d6e543221b9b9038ee557531c7f8f8a7a8c3aa37d2ca0e4505ef844b457aedc4a6b8e705545b290c', '2024-06-01 01:32:50', 0),
(44, 'developer', '49e5f68dc1c1b572b8d41d051dad339520f4fb266ef3ba9683d1ea03f75a2702bdbf7d310128d51e7f13f353791c719e9b9b8e43178368675066cd213d09fd88f8c40a559a5d92d0b3d8597c6419b048740f7c16ae14aedfb113f04f602ba0578e0f7b75cfa5f3dfed13c23fb76962de1ef06f019b3dec77b57fb44d880a8280', '2024-06-01 01:43:50', 0),
(45, 'Megha', '75de6075bce9cddc5756f5c50ec28294366eea531efc917d0a54bd0f98070f1b1b2ea79a697c1e0207a021b68209241bd99f09351be7587a1ffe3a098ed0976bcbb75d368ecc00d9d091eddef0a298607ccf268366a9b498f71f5f10fe8dce8512140748209209494755b28053ab26a974e89b5378614269f3f01b2d5e768207', '2024-06-01 01:44:53', 0),
(46, 'developer', '8e941d28b5c030056a50d3f992d585b655bf7903df78dd2aa79f9607288fdb6bce4e17c1820b0ed2dc5198970aa80396adb3be5531dc5362d9c77286abb06268f7be54c3ffa7c684492d96a7722ef49d65c32a72d9349a0a0877619e854813fc326bdea8ef10f2eedfdf33a68f3f23ac7b2245907772cd5eaabadd5968fb327d', '2024-06-01 01:46:12', 0),
(47, 'developer', '0c3ebb3bdafb82d0f8affaf37b71d9210d2b51833c91a5af74bc8d41f69c2c60effa284f4bb682739c2bdd2e6c10f95436732028e682c5f45e9a500d2ec359dd10feead25ae630da23a0056a4736c5d2b6c9e2d5eae54c0eede27300b9f2eae86222f238c9e4faaa5655ea9c9b68ed3aa6c5ce9ecb5547bb62acec75a8d224ad', '2024-06-01 02:10:40', 0),
(48, 'developer', 'f28e9400823a1df7aedfeb979f71c8a5ba96009854e9061a3e5eb6c3b27e4a3d15f8c35a1d073470c7b889cb5ff4132dc59f9646ebed51a910b1ea43b36cbcb987449874bc970f67fa1f0406bc4c58b498efcc4dc5032abcb1a869ccf52862c6426bacd822bf12de041397bbc8426e822352ee59e16cf107efcca6a0efa6cf19', '2024-06-05 01:11:00', 0),
(49, 'developer', 'ccc8b491222fc0e2a9c92083721870ee9d0556b421c58aeaa24051ee419414afee490a3955bbfef05ad3807fdaa5ca04eee7a807d1fe37025e486b1fe482d329b85d3aabcb3bae9da9459c356ba27bd14a350aede4232f079252ae228036f85d7da04c2716dfe6963e978695b56764109f4459432d9d7ee2c208557eba874138', '2024-06-05 01:15:05', 0),
(50, 'developer', '8f5e7788e6740bebe16648e56bb44db2df795e933b14ab90b7dda8af7715fd24bf62e83620ed150208a886bb322d0ab8a15a50c17729bda5634666932500ed0b03bd201983ed51a8b2fd834f1309db244fd72b31fee70ce0d1662ed25027df129358e687292bfcbec39a9e15b303d77b429e00abf80db420d068cc38fb973e9b', '2024-06-06 15:29:51', 0),
(51, 'developer', 'ad61953303b5908619d45e6f0b958f6e5df6a5fbeb88571c30ecb520592bb935a029b71c802a1c49ca8fc2aecd48218bf280daa74c9b4235b9e30ce207f5778608c4527e042a11e33e2a3f0f5b08842165008ff9a08d5ce3d3b9b23d949235b88a0f38540a8f449459b5ba2fdec0e3e356795c75d1aafd8c5bc679395c33a106', '2024-06-06 15:42:10', 0),
(52, 'developer', 'bcbfa66845ecbcf4a7239a4aba376838906d8aa47e9e07cbe305e1f4ee259dd18d47750001670a7cb8565c2ffedb549801c35687829de0e52bfecd8672e77c0de986240b582db82d7186b66debd6361730439191678155abe882805fd42700a4b1db31f88b2a96e34f0212d88c76ffa41ac46a4561d7af3b1ae27011cf9602a8', '2024-06-07 08:03:44', 1);

-- --------------------------------------------------------

--
-- Table structure for table `student_data`
--

CREATE TABLE `student_data` (
  `sl` int(11) NOT NULL,
  `userid` varchar(2000) NOT NULL,
  `fullname` varchar(3000) NOT NULL,
  `mob` varchar(200) NOT NULL,
  `emailid` varchar(1000) NOT NULL,
  `yearid` varchar(1000) NOT NULL,
  `stat` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_data`
--

INSERT INTO `student_data` (`sl`, `userid`, `fullname`, `mob`, `emailid`, `yearid`, `stat`) VALUES
(1, 'atana', 'atunukumar das', '12345678987654', 'biswajitkpa6@gmail.com', 'ug 1', 1),
(3, 'Megha', 'Megha Bangari', '654754756', 'meghabangari7009@gmail.com', 'UG-III', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addmission_link`
--
ALTER TABLE `addmission_link`
  ADD PRIMARY KEY (`sl`);

--
-- Indexes for table `dept_gallery`
--
ALTER TABLE `dept_gallery`
  ADD PRIMARY KEY (`sl`);

--
-- Indexes for table `dept_magazine`
--
ALTER TABLE `dept_magazine`
  ADD PRIMARY KEY (`sl`);

--
-- Indexes for table `dept_notice`
--
ALTER TABLE `dept_notice`
  ADD PRIMARY KEY (`sl`);

--
-- Indexes for table `edu_login`
--
ALTER TABLE `edu_login`
  ADD PRIMARY KEY (`sl`);

--
-- Indexes for table `login_key`
--
ALTER TABLE `login_key`
  ADD PRIMARY KEY (`sl`);

--
-- Indexes for table `student_data`
--
ALTER TABLE `student_data`
  ADD PRIMARY KEY (`sl`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addmission_link`
--
ALTER TABLE `addmission_link`
  MODIFY `sl` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `dept_gallery`
--
ALTER TABLE `dept_gallery`
  MODIFY `sl` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dept_magazine`
--
ALTER TABLE `dept_magazine`
  MODIFY `sl` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `dept_notice`
--
ALTER TABLE `dept_notice`
  MODIFY `sl` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `edu_login`
--
ALTER TABLE `edu_login`
  MODIFY `sl` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `login_key`
--
ALTER TABLE `login_key`
  MODIFY `sl` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `student_data`
--
ALTER TABLE `student_data`
  MODIFY `sl` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
