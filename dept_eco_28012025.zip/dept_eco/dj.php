<?php
//header('location:portal');
//die();
include "controller.php";
if($ck==1){
  header('location:portal/index.php');
}
else{
echo "AWFHUQRFH";
}
?>
