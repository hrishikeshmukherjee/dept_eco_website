<header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex align-items-center">
      <h1 class="logo me-auto"><a href="index.html">Department Of Economics<span>.</span></a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
          <li><a class="nav-link scrollto" href="#about">About</a></li>
          <!--<li><a class="nav-link scrollto" href="#services">Event</a></li>-->
          <li><a class="nav-link scrollto " href="#portfolio">Gallery</a></li>
          <li><a class="nav-link scrollto" href="#team">Faculty</a></li>
          <li><a class="nav-link scrollto" href="#activities">Contact</a></li>
          <li class="dropdown"><a href="#"><span>Academics</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="admission.php">Admission</a></li>
              <li><a href="previous_year_question.php">Previous Year Question</a></li>
              <!--<li><a href="#">Department Routine</a></li>-->
              <li><a href="https://vidyamandira.ac.in/department/economics/ECON_Major_Syll_upto_SEMIV.pdf" target="">Syllabus</a></li>
              <li><a href="stu_corner.php">Student's Corner</a></li>
            </ul>
          </li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

      <a href="alumni/index.php" class="get-started-btn scrollto">Alumni</a>
    </div>
  </header>