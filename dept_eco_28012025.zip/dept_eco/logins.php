<?php
include "controller.php";
if($ck==0){
  $username=$_POST['username'];
  $password=$_POST['password'];
  if($username==""){
    ?>
    <script>
    alert	('Please Enter Username');
    history.go(-1);
    </script>
    <?php
  }
  elseif($password==""){
    ?>
    <script>
    alert('Please Enter Password');
    history.go(-1);
    </script>
    <?php
  }
  else{
    $getCheck=mysqli_query($conn,"SELECT * FROM `edu_login` WHERE `username`='$username' AND `stat`= '1'");
    if($rowCheck=mysqli_fetch_array($getCheck)){
      $passwordHash=$rowCheck['password'];
      if(password_verify($password,$passwordHash)){
        mysqli_query($conn,"UPDATE `edu_login` SET `logintime`='$currentDateTime' WHERE `username`='$username'");
        $loginKey = openssl_random_pseudo_bytes(128);
        $loginKey = bin2hex($loginKey);
        $_SESSION["loginKey"]=$loginKey;
        mysqli_query($conn,"UPDATE `login_key` SET `stat`=0 WHERE `username`='$username'");
        mysqli_query($conn,"INSERT INTO `login_key`(`username`, `loginKey`, `edt`, `stat`) VALUES('$username', '$loginKey', '$currentDateTime', '1')");
        ?>
        <script>
        alert('Login Successfully');
        document.location="portal/index.php";
        </script>
        <?php
      }else{
        ?>
        <script>
        alert('Please Enter valid Username & Password');
        history.go(-1);
        </script>
        <?php
      }
    }
    else{
      ?>
      <script>
      alert('Please Enter valid Username & Password');
      history.go(-1);
      </script>
      <?php
    }
  }
}
else{
  header('location:origin.php');
}
?>
