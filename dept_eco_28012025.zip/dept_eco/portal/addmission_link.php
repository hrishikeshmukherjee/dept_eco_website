<?php

 if (isset($_POST['upload'])) {
     
     $links=$_POST['links'];
    mysqli_query($conn,"INSERT INTO `addmission_link` (`link`,`stat`) VALUES ('$links','1');");
  }
  ?>
    <section id="facts" class="facts">
      <div class="container">

        <div class="section-title">
          <h2>Admission Link Paste</h2>

          <form action="?" method="post" enctype="multipart/form-data">
    <div class="container">

<div class="section-title">
</div>

<div class="row">
  <div class="card">
    <div class="card-body">
    <div class="mb-3">
        <label for="exampleFormControlTextarea1" class="form-label">Paste the Link here</label>
        <textarea class="form-control" id="links" name="links" rows="3"></textarea><br>
        <input type="submit" class="form-control" name="upload" value="Upload ">
    </div>
    </div>
  </div>
</div>
</div>
    </form>
          
        </div>

        <div class="row no-gutters">

          

      </div>
    </section>