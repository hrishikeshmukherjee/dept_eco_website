<?php

 if (isset($_POST['uuploads'])) {

     
     $file_name = $_FILES['file']['name'];
     $file_type = $_FILES['file']['type'];
     $file_size = $_FILES['file']['size'];
     $file_temp_loc = $_FILES['file']['tmp_name'];
     $file_store = "../assets/img/gallery/".$file_name;
     $file_storedb = "assets/img/gallery/".$file_name;
     
     move_uploaded_file($file_temp_loc, $file_store);
     
     $name=$_POST['name'];
     $year=$_POST['year'];
     $fav=$_POST['fav'];
     $words=$_POST['words'];
    mysqli_query($conn,"INSERT INTO `dept_gallery` (`img_path`,`name`,`year`,`fav`,`words`,`stat`) VALUES ('$file_storedb','$name','$year','$fav','$words','1');");
  }
  ?>
<section id="gallery" class="gallery">
<form action="?" method="post" enctype="multipart/form-data">
    <div class="container">

<div class="section-title">
<h2>Member's Gallery</h2>
</div>

<div class="row">
  <div class="card">

    <div class="card-body">
    <div class="mb-3">
      <label for="exampleFormControlInput1" class="form-label">Choose Your Picture</label>
      <input type="file" class="form-control"  name="file"  value="" >
    </div>
    <div class="mb-3">
    <label for="exampleFormControlTextarea1" class="form-label">Your Name</label>
        <input class="form-control" type="text" name="name" id="name">


        <label for="exampleFormControlTextarea1" class="form-label">Year</label>
        <input class="form-control" type="text" name="year" id="year" placeholder="UG-I"><br>

        <label for="exampleFormControlTextarea1" class="form-label">Favorite Movie/Anime</label>
        <input class="form-control" type="text" name="fav" id="fav" placeholder="One Piece"><br>

        <label for="exampleFormControlTextarea1" class="form-label">Your Words</label>
        <input class="form-control" type="text" name="words" id="words" placeholder=""><br>
        <input type="submit" class="form-control" name="uuploads" value="Upload Image">
    </div>
    </div>
  </div>
</div>
</div>
    </form>
</section>