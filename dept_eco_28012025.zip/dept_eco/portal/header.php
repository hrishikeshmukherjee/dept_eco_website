<header id="header">
    <div class="d-flex flex-column">

      <div class="profile">
        <img src="assets/img/profile-img.jpg" alt="" class="img-fluid rounded-circle">
        <h1 class="text-light"><a href="index.html"><?php echo "$log_fullname"; ?></a></h1>
        <div class="social-links mt-3 text-center">
          <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
          <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
          <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
          <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
          <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
        </div>
      </div>

      <nav id="navbar" class="nav-menu navbar">
        <ul>
          <li><a href="#hero" class="nav-link scrollto active"><i class="bx bx-home"></i> <span>Home</span></a></li>
          <li><a href="#gallery" class="nav-link scrollto active"><i class="bx bx-home"></i> <span>Gallery</span></a></li>
          <?php
            if($log_userlevel<=5){
              ?>
              <li><a href="#resume" class="nav-link scrollto"><i class="bx bx-file-blank"></i> <span>Events</span></a></li>
              <li><a href="#magazine" class="nav-link scrollto"><i class="bx bx-file-blank"></i> <span>Eco-Book</span></a></li>
              <li><a href="#members" class="nav-link scrollto"><i class="bx bx-file-blank"></i> <span>Members</span></a></li>
              <!--<li><a href="#services" class="nav-link scrollto"><i class="bx bx-server"></i> <span>Class Notes</span></a></li>-->
              <?php
            }
          ?>
          <!--<li><a href="#stu_services" class="nav-link scrollto"><i class="bx bx-server"></i> <span>Class Notes</span></a></li>-->
          <li><a href="logout.php" class="nav-link scrollto"><i class="bx bx-logout"></i> <span><b>Logout</b></span></a></li>
        </ul>
      </nav><!-- .nav-menu -->
    </div>
  </header>