<?php
include '../controller.php';
if ($ck == 1) {
  mysqli_query($conn, "UPDATE `login_key` SET `stat`=0 WHERE `username` = '$log_username'");
}
session_unset();

session_destroy();

session_start();

session_regenerate_id();

header("location: ../index.php");
 ?>
