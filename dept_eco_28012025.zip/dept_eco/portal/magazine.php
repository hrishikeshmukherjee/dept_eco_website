<section id="magazine" class="magazine">
  <h3>
  <?php
      $getImg = mysqli_query($conn, "SELECT * FROM `dept_ecobook` WHERE `stat`='0'");
      while ($rowImg = mysqli_fetch_array($getImg)) {
          $sl = $rowImg['sl'];
          $img_path = $rowImg['img_path'];
          $headline = $rowImg['headline'];
          $article = $rowImg['article'];
          $userid = $rowImg['userid'];
          $roll = $rowImg['roll'];
          $date = $rowImg['date'];
      
      ?>

        <div class="post mt-5"><br>
            <h2><p><?php echo"$headline";?></p></h2>
            <h3 class="text-center"><img src="<?php echo "../ecobook/$img_path";?>" alt="" height="450px" width="500px"></h3>
            <font face="verdana"><p><?php echo"$article";?></p></font>
            <p class="text-right"><?php echo"$userid - $roll";?></p>
            <p class="text-right"><?php echo"$date";?></p>
              <form action="">
                
              </form>
            <?php }?>
  </h3>
</section>
