  <section id="members" class="members">
  <div class="container">
      <div class="section-title">
        <h2>Applied-List</h2>
      </div>
    <div class="row">
      <div class="card">
        <div class="card-body">
          <h3>Applied Students</h3>
          <table class="table table-striped ">
            <thead class="thead-dark">
              <th>
                <td>Sl.</td>
                <td>Name</td>
                <td>Mobile</td>
                <td colspan="2">Action</td>
              </th>
            </thead>
            <?php
              $cnt=0;
              $get=mysqli_query($conn, "SELECT * FROM `edu_login` WHERE `stat`='2'");
              while ($row=mysqli_fetch_array($get)) {
              $cnt++;
              $sl=$row['sl'];
              $fullname=$row['fullname'];
              $mobile=$row['mobile'];
            ?>
            <tbody>
              <tr>
                <td></td>
                <td><?php echo "$cnt";?></td>
                <td><?php echo "$fullname";?></td>
                <td><?php echo "$mobile";?></td>
                <td> <a href="accept.php?sl=<?php echo $sl; ?>">Accept</a> <font color="white">dd</font><a href="decline.php?sl=<?php echo $sl; ?>">Decline</a></td>
              </tr>
              <?php } ?>
            </tbody>
          </table>
          
        </div>
      </div>
    </div>


<br><br>
  
  
    <div class="section-title">
        <h2>Members-List</h2>
      </div>
    <div class="row">
      <div class="card">
        <div class="card-body">
          <h3>Members</h3>
          <table class="table table-striped ">
            <thead class="thead-dark">
              <th>
                <td>Sl.</td>
                <td>Name</td>
                <td>Mobile</td>
                <td>Gmail</td>
              </th>
            </thead>
            <?php
              $cnt=0;
              $get=mysqli_query($conn, "SELECT * FROM `edu_login` WHERE `stat`='1'");
              while ($row=mysqli_fetch_array($get)) {
              $cnt++;
              $sl=$row['sl'];
              $fullname=$row['fullname'];
              $mobile=$row['mobile'];
              $email=$row['email'];
            ?>
            <tbody>
              <tr>
                <td></td>
                <td><?php echo "$cnt";?></td>
                <td><?php echo "$fullname";?></td>
                <td><?php echo "$mobile";?></td>
                <td><?php echo "$email";?></td>
              </tr>
              <?php } ?>
            </tbody>
          </table>
          
        </div>
      </div>
    </div>
  </div>
</section>
