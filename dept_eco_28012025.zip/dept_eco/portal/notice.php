<?php

 if (isset($_POST['upload'])) {

     
     $file_name = $_FILES['file']['name'];
     $file_type = $_FILES['file']['type'];
     $file_size = $_FILES['file']['size'];
     $file_temp_loc = $_FILES['file']['tmp_name'];
     $file_store = "../assets/img/notice/".$file_name;
     $file_storedb = "assets/img/notice/".$file_name;
     
     move_uploaded_file($file_temp_loc, $file_store);
     
     $textarea=$_POST['textarea'];
    mysqli_query($conn,"INSERT INTO `dept_notice` (`img_path`,`instructions`,`stat`) VALUES ('$file_storedb','$textarea','1');");
  }
  ?>
<section id="resume" class="resume">
<form action="?" method="post" enctype="multipart/form-data">
    <div class="container">

<div class="section-title">
  <h2>Upcomming Events</h2>
</div>

<div class="row">
  <div class="card">
    <div class="card-body">
    <div class="mb-3">
      <label for="exampleFormControlInput1" class="form-label">Choose File</label>
      <input type="file" class="form-control"  name="file"  value="" >
    </div>
    <div class="mb-3">
        <label for="exampleFormControlTextarea1" class="form-label">Instructions(Optional)</label>
        <textarea class="form-control" id="textarea" name="textarea" rows="3"></textarea><br>
        <input type="submit" class="form-control" name="upload" value="Upload Image">
    </div>
    </div>
  </div>
</div>
</div>
    </form>
</section>