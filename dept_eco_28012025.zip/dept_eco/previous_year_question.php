<?php include "controller.php"; ?>
<!DOCTYPE html>
<html lang="en">

<head>
<?php include "link.php";?>
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex align-items-center">
      <h1 class="logo me-auto"><a href="index.html">Department Of Economics<span>.</span></a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="nav-link scrollto active" href="index.php">Home</a></li>
          <li><a class="nav-link scrollto" href="index.php">About</a></li>
          <!--<li><a class="nav-link scrollto" href="#services">Event</a></li>-->
          <li><a class="nav-link scrollto " href="index.php">Gallery</a></li>
          <li><a class="nav-link scrollto" href="index.php">Faculty</a></li>
          <li><a class="nav-link scrollto" href="index.php">Contact</a></li>
          <li class="dropdown"><a href="stu_corner.php"><span>Academics</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="admission.php">Admission</a></li>
              <li><a href="previous_year_question.php">Previous Year Question</a></li>
              <!--<li><a href="#">Department Routine</a></li>-->
              <li><a href="https://vidyamandira.ac.in/department/economics/ECON_Major_Syll_upto_SEMIV.pdf" target="">Syllabus</a></li>
              <li><a href="stu_corner.php">Student's Corner</a></li>
            </ul>
          </li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

      <a href="alumni/index.php" class="get-started-btn scrollto">Alumni</a>
    </div>
  </header><!-- End Header -->

  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <section class="breadcrumbs">
      <div class="container">
        <h2>Previous Year Questions</h2>

      </div>
    </section><!-- End Breadcrumbs -->

    <section class="inner-page">
      <div class="container" data-aos="fade-up">
        <div class="card">
            <div class="card-header">
            <b>PREVIOUS YEAR QUESTION PAPERS OF ADMISSION TEST</b>
            </div>
            <div class="card-body">
            <div class="row"> 
            <div class="col-md-3"><a target="blank" href="https://vidyamandira.ac.in/pdfs/adm_prev_qstn/eco.pdf">Admission Question paper 2013</a></div>
            <div class="col-md-3"><a target="blank" href="https://vidyamandira.ac.in/pdfs/adm_prev_qstn/2014/eco.pdf">Admission Question paper 2014</a></div>
            <div class="col-md-3"><a target="blank" href="https://vidyamandira.ac.in/pdfs/adm_prev_qstn/2015/eco.pdf">Admission Question paper 2015</a></div>
            <div class="col-md-3"><a target="blank" href="https://vidyamandira.ac.in/pdfs/adm_prev_qstn/2016/eco.pdf">Admission Question paper 2016</a></div>
        </div><br>
        <div class="row"> 
        <div class="col-md-3"><a target="blank" href="https://vidyamandira.ac.in/pdfs/adm_prev_qstn/2017/ECONOMICS.pdf">Admission Question paper 2017</a></div>
        <div class="col-md-3"><a target="blank" href="https://vidyamandira.ac.in/pdfs/adm_prev_qstn/2018/ECONOMICS.pdf">Admission Question paper 2018</a></div>
        <div class="col-md-3"><a target="blank" href="https://vidyamandira.ac.in/pdfs/adm_prev_qstn/2019/ECONOMICS.pdf">Admission Question paper 2019</a></div>
        <div class="col-md-3"><a target="blank" href="https://vidyamandira.ac.in/pdfs/adm_prev_qstn/2022/ECONOMICS.pdf">Admission Question paper 2022</a></div>
        </div><br>
            </div>
        </div>


        
      </div>
    </section>

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact">
            <h3>Depertment Of Economics<span>.</span></h3>
            <p>
              Ramakrishna Mission Vidyamandira <br>
              Howrah Belur Math<br>
              India <br><br>
              <strong>Phone:</strong> 2654-9181/9632<br>
              <strong>Email:</strong> vidyamandira@gmail.com<br>
            </p>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">About us</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Faculty</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Gallery</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Academics</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="admission.php">Admission</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="previous_year_question.php">Previous Year Questions</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="https://vidyamandira.ac.in/department/economics/ECON_Major_Syll_upto_SEMIV.pdf">Syllabus</a></li>
            </ul>
          </div>

          <div class="col-lg-4 col-md-6 footer-newsletter">
            <h4>Join Our Depertment</h4>
            <p>Check On the Official <a href="https://vidyamandira.ac.in/">Ramakrishna Mission Vidyamandira</a> site</p>
          </div>

        </div>
      </div>
    </div>

    <div class="container d-md-flex py-4">

      <div class="me-md-auto text-center text-md-start">
        <div class="copyright">
          &copy; Copyright <strong><span>Economics Depertment - Ramakrishna Mission Vidyamandira</span></strong>. All Rights Reserved
        </div>
        <div class="credits">
          <!-- All the links in the footer should remain intact. -->
          <!-- You can delete the links only if you purchased the pro version. -->
          <!-- Licensing information: https://bootstrapmade.com/license/ -->
          <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/presento-bootstrap-corporate-template/ -->
          Designed by <a href="index.php">Students Of Economics Department( UG-II)</a>
        </div>
      </div>
      
    </div>
  </footer>

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>