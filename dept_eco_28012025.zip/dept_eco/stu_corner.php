<?php include "controller.php"; ?>
<!DOCTYPE html>
<html lang="en">

<head>
<?php include "link.php";?>
</head>

<body>

<header id="header" class="fixed-top d-flex align-items-center">
    <div class="container d-flex align-items-center">
      <h1 class="logo me-auto"><a href="index.html">Department Of Economics<span>.</span></a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="nav-link scrollto active" href="index.php">Home</a></li>
          <li><a class="nav-link scrollto" href="index.php">About</a></li>
          <!--<li><a class="nav-link scrollto" href="#services">Event</a></li>-->
          <li><a class="nav-link scrollto " href="index.php">Gallery</a></li>
          <li><a class="nav-link scrollto" href="index.php">Faculty</a></li>
          <li><a class="nav-link scrollto" href="index.php">Contact</a></li>
          <li class="dropdown"><a href="#"><span>Academics</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="admission.php">Admission</a></li>
              <li><a href="previous_year_question.php">Previous Year Question</a></li>
              <!--<li><a href="#">Department Routine</a></li>-->
              <li><a href="https://vidyamandira.ac.in/department/economics/ECON_Major_Syll_upto_SEMIV.pdf" target="">Syllabus</a></li>
              <li><a href="stu_corner.php">Student's Corner</a></li>
            </ul>
          </li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

      <a href="alumni/index.php" class="get-started-btn scrollto">Alumni</a>
    </div>
  </header>

  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <section class="breadcrumbs">
      <div class="container">
        <h2>Student's Corner</h2>

      </div>
    </section><!-- End Breadcrumbs -->

    <section class="inner-page">
      <div class="container" data-aos="fade-up">
      <div class="card mb-4">
                    <div class="card-body">
                        <h2 class="post-title">Life of Vidyamandira:  The Temple of Learning</h2>
                        <p class="post-date">Posted on September 21, 2024</p>
                        <p class="post-content">
                        In Vidyamandion everyone have to go through the traditions that have a rare precedent in the outer world . The students have to maintain, a hard and fast schedule here which is actually the key of perfection of the Vidyamandra family members .
                        I'm Rajdip Mandal, get the bliss of THAKUR- MAA- SWAMIJI and has got admission to this admired institution. I have already spent here about 2 months. Now I want to share my experience with all of you. The schedule of Vidyamandira  not so unknown to me as I have spent my schooldays  Ramakrishna Mission ( Rahara) but here I have rediscovered the every old as a new. Over every facinates the one that attracts my vision is the holy ceremony, "Bhatrivaran  and Vidyarthibrata " In this programme/rite the college welcomes the freshers in a botherly affection, I.e Significance  title within. Here the teacher-student relationship in unconditional and our Maharajs are like spines of inspiration.
                        I think it is the temple of learning, the place of peace and the door of introspection. I want to acknowledge to the almighty Devine to be a student of R.K.M Vidyamandira.
                        </p>
                    </div>
                    <div class="card-footer text-muted">
                        Posted by <a href="#">Rajdip Mandal UG-I</a>
                    </div>
                </div>

                <div class="card mb-4">
                    <div class="card-body">
                        <h2 class="post-title">Student Of Economics of Vidyamandira</h2>
                        <p class="post-date">Posted on July 23, 2024</p>
                        <p class="post-content">
                        As a second-year undergraduate student in the Economics department at Ramakrishna Mission Vidyamandira, life is a blend of rigorous academic learning and a well-rounded personal growth experience. The department provides a strong foundation in economic theories, quantitative techniques, and contemporary economic issues, fostering critical thinking and analytical skills. Students engage in classroom lectures, seminars, and discussions that encourage a deeper understanding of microeconomics, macroeconomics, and statistical methods. The faculty is highly supportive, ensuring that students grasp complex concepts through interactive teaching methods. Life on campus is disciplined yet enriching, with ample opportunities to participate in extracurricular activities, cultural programs, and community service, all of which are integral to the college’s values of holistic development. The ashram-based environment promotes a calm and focused lifestyle, which is conducive to both academic excellence and personal well-being, helping students to not only excel in their studies but also develop a strong moral compass.
                        </p>
                    </div>
                    <div class="card-footer text-muted">
                        Posted by <a href="#">Ankit Ghosh UG-II</a>
                    </div>
                </div>
      </div>
                </div>
      </div>
      </div>

      
    </section>

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact">
            <h3>Depertment Of Economics<span>.</span></h3>
            <p>
              Ramakrishna Mission Vidyamandira <br>
              Howrah Belur Math<br>
              India <br><br>
              <strong>Phone:</strong> 2654-9181/9632<br>
              <strong>Email:</strong> vidyamandira@gmail.com<br>
            </p>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">About us</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Faculty</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Gallery</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Academics</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="admission.php">Admission</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="previous_year_question.php">Previous Year Questions</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="https://vidyamandira.ac.in/department/economics/ECON_Major_Syll_upto_SEMIV.pdf">Syllabus</a></li>
            </ul>
          </div>

          <div class="col-lg-4 col-md-6 footer-newsletter">
            <h4>Join Our Depertment</h4>
            <p>Check On the Official <a href="https://vidyamandira.ac.in/">Ramakrishna Mission Vidyamandira</a> site</p>
          </div>

        </div>
      </div>
    </div>

    <div class="container d-md-flex py-4">

      <div class="me-md-auto text-center text-md-start">
        <div class="copyright">
          &copy; Copyright <strong><span>Economics Depertment - Ramakrishna Mission Vidyamandira</span></strong>. All Rights Reserved
        </div>
        <div class="credits">
          <!-- All the links in the footer should remain intact. -->
          <!-- You can delete the links only if you purchased the pro version. -->
          <!-- Licensing information: https://bootstrapmade.com/license/ -->
          <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/presento-bootstrap-corporate-template/ -->
          Designed by <a href="index.php">Students Of Economics Department( UG-II)</a>
        </div>
      </div>
      
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>